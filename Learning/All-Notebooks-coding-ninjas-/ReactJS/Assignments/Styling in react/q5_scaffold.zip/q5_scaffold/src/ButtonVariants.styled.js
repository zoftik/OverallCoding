import styled from "styled-components";

export const ButtonView = styled.button`
  text-transform: uppercase;
  background-color: ${(props) => (props.filled ? props.bg : "#fff")};
  color: ${(props) => (props.filled ? props.color : "#000")};
  border: ${(props) => (props.filled ? "none" : "3px solid #000")};
`;