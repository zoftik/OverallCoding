// Complete the HomePage Component and export it
import Form from './Form';

var name = "abc"
var email = "abc@email.com"

export default function HomePage() {
  return (
    <div className="Homepage">
      <h1>HomePage</h1>
      <h3>Login Page</h3>
      <Form/>
    </div>
  );
}

export {email, name}