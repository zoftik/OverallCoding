import "./styles.css";
import { Component } from "react";

class Skills extends Component {
    render() {
      return (
        
        <div className="skills">
            <ul>
                <li><p>HTML</p></li>
                <li><p>css</p></li>
                <li><p>React</p></li>
                <li><p>JavaScript</p></li>
                <li><p>Node</p></li>
            </ul>
        </div>
      );
    }
  }

export default Skills;
