import "./styles.css";
import { Component } from "react";

class About extends Component {
    render() {
      return (
        <div className="about">
          
          <p>
            Hi,My name is pravan.I am full stack web developer and i have developed several projects with mern stack. I am also familier with Python and Django
          </p>
        </div>
      );
    }
  }

export default About;
