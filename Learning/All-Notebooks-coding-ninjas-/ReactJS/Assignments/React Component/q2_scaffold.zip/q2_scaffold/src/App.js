import "./styles.css";
import { Component } from "react";
import About from "./About";
import Hero from "./Hero";
import Skills from "./Skills";

export default function App() {
  return (
    <div className="App">
      
      <Hero />
      <br/><br/>
      <Skills />
      <br/><br/>
      <About />

    </div>
  );
}
