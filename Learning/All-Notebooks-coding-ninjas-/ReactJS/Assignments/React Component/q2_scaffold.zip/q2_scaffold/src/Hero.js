import "./styles.css";
import { Component } from "react";


class Hero extends Component {
    render() {
      return (
        <div className="hero">
          <b>Name: Pranva Sharad Yeole</b>
          <p>Email:  pranav@google.com</p>
          <p>Phone:  8546465544</p>
          <p>Address:  ABC, xyz street</p>

        </div>
      );
    }
  }

export default Hero;