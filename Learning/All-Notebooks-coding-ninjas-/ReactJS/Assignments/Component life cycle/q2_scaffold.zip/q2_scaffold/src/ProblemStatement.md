Your friend has built an app that displays the people inside your network. Now you both decided to collaborate on this project, and you are expected to add the following functionality -

- There should be an option to remove a person from the network and display an alert accordingly.

Expected Output -
<img src=”https://res.cloudinary.com/dl26pbek4/image/upload/v1675861282/cn-gifs/network-app_nliesb.gif” />

Hint: The index of the person should be used to change the show property to conditionally render the Person component.
